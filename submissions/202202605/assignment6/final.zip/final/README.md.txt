# 단어 난이도 분류 및 스페인어 번역 도구

## 실행 방법 (Windows CMD 기준)

### 시스템 요구 사항

1. Windows 운영체제
2. Python 3.9 이상 설치
3. 인터넷 연결 필수

본 프로젝트에서 사용한 학습된 모델은 Hugging Face에 업로드되어 있습니다. 실행 시 Transformers 라이브러리를 통해 모델과 토크나이저가 자동으로 다운로드되어 로드됩니다. 

Hugging Face 모델 링크
https://huggingface.co/YESONG525H/word-classifier/tree/main
※ 링크는 오직 참고용이며 별도로 다운로드할 필요는 없습니다

### 실행 순서 

1. CMD를 실행한 후 프로젝트 폴더로 이동합니다
cd [final 파일 경로를 입력하세요]

2. 가상 환경을 생성합니다
python -m venv venv

3. 가상 환경을 활성화합니다
venv\Scripts\activate

4. 필요한 라이브러리를 설치합니다
pip install -r requirements.txt

5. 애플리케이션을 실행합니다
streamlit run app.py
: 정상적으로 실행되면 웹 브라우저에서 아래 주소로 접속됩니다
http://localhost:8501/

## 사용 방법
1. 텍스트 파일(.txt) 업로드 또는 텍스트를 직접 입력합니다
2. Analyze Text 버튼을 클릭하면 모델이 단어 단위로 텍스트를 분석합니다
ㄴ final 폴더 내 test_sample.txt 파일 사용 가능
3. 알기 어려운 단어가 노랑색으로 하이라이트 표시되며 스페인어 번역 결과가 제공됩니다
